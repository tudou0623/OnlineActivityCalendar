function right_change(){
	//alert("haha");
	window.document.getElementById("left").style.width="1%";
	window.document.getElementById("right").style.width="15%";
	window.document.getElementById("right").style.left="85%";
	window.document.getElementById("middle").style.left="1%";
	};
function right_change2(){
	//alert("hehe");
	window.document.getElementById("left").style.width="15%";
	window.document.getElementById("right").style.width="1%";
	window.document.getElementById("right").style.left="99%";
	window.document.getElementById("middle").style.left="15%";
	};
	
	
function expand(object){
	//alert(object.style.width);
	object.style.height="40%";
	};
	
function shrink(object){
	object.style.height="15%";
	};